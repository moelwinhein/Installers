/*jslint vars: true, plusplus: true, devel: true, browser: true, nomen: true, indent: 4 */
/*global define, brackets, describe, it, expect, beforeEach, afterEach */
define(function (require, exports, module) {
    'use strict';

    require('unittests/main.test');

});
