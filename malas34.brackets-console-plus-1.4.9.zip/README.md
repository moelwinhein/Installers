Console Plus
================

A Brackets extension to see console.log & console.error in a Brackets Panel

* Toolbar Icon + Notifier
* Filters by logs/errors/warns
* View logs stacks details (collapsible)
* Show caller's filename
* Clear console
* Really nice look :D
* CTRL + F12 Show panel shortcut
* Open files in brackets

![Screenshot](https://github.com/malas34/brackets-console-plus/blob/master/screenshot.jpg)


> Based on
> v1.2.0 by Alexandru Ghiura & Alain Kalker

> https://github.com/ghalex/brackets-console
