#### v1.4.4

Add opened at startup form previous session

#### v1.4.1

Click on file's name open file in brackets
Brackets 0.44 API update

#### v1.4.0

Version

#### v1.3.10

Add CTRL+F12 Keys Shortcut
Remove 'windows' menu

#### v1.3.9

Warns added
Debug array
Debug object (no circular json)

#### v1.3.8

Dark theme
Message filters (log/error)
Toolbar icon + Notifier
Filename
Full error stack collapsible

#### v1.2.0
Based on [v1.2.0](https://github.com/ghalex/brackets-console) by Alexandru Ghiura & Alain Kalker
