/*jslint indent: 4 */
/*global module */
module.exports = {
    options: {
        compress: false
    },
    dev: {
        files: {
            "./styles/styles.css": "./styles/styles.less"
        }
    }
};
