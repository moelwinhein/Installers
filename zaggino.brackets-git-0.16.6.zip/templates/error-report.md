[I'm supposed to describe steps to replicate my issue here and if I don't do that, I understand that my issue will be probably ignored.]

--------------------------------

*{{brackets}}{{#git}}, Git {{git}}{{/git}} & {{bracketsGit}}*

{{#title}}**{{title}}**{{/title}}

{{#errorBody}}```
{{{errorBody}}}
```{{/errorBody}}

{{#errorStack}}```
{{{errorStack}}}
```{{/errorStack}}
