brackets-console
================

A Brackets extension to see console.log & console.error without developer tools. Can also be used to filter out only the logs coming from a live preview window.

![Screenshot](https://raw.github.com/aghiura/brackets-console/master/assets/preview.png)
